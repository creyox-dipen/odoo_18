# -*- coding: utf-8 -*-
# Part of Creyox Technologies.

from . import account_move